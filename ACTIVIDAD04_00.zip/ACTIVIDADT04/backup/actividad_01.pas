unit ACTIVIDAD_01;

{$mode ObjFPC}{$H+}

interface

uses
  SysUtils;

type
  TVector = array of Integer;
  VectorPlus = class
  private
    V: TVector;
  public
    procedure Cargar(A: TVector);
    function CantidadCortes: Integer;
    function ElementosEntreCortes: String;
    procedure DividirParImpar(out Pares, Impares: TVector);
    function Intercalar(B: TVector): TVector;
    procedure Purgar;
    function Mostrar: String;
  end;

implementation

procedure VectorPlus.Cargar(A: TVector);
var
  i: Integer;
begin
  SetLength(V, Length(A));

  for i := 0 to High(A) do
    V[i] := A[i];
end;

function VectorPlus.CantidadCortes: Integer;
var
  i: Integer;
begin
  Result := 0;

  for i := 1 to High(V) do
    if V[i] <> V[i - 1] then
      Result := Result + 1;
end;

function VectorPlus.ElementosEntreCortes: String;
var
  i, frecuencia: Integer;
begin
  Result := '';
  if Length(V) = 0 then Exit;

  frecuencia := 1;

  for i := 1 to High(V) do
  begin
    if V[i] = V[i - 1] then
      frecuencia := frecuencia + 1
    else
    begin
      Result := Result + IntToStr(V[i - 1]) +
        ': ' + IntToStr(frecuencia) + LineEnding;
      frecuencia := 1;
    end;
  end;

  Result := Result + IntToStr(V[High(V)]) +
    ': ' + IntToStr(frecuencia);
end;

procedure VectorPlus.DividirParImpar(
  out Pares, Impares: TVector);
var
  i: Integer;
begin
  SetLength(Pares, 0);
  SetLength(Impares, 0);

  for i := 0 to High(V) do
  begin
    if V[i] mod 2 = 0 then
    begin
      SetLength(Pares, Length(Pares) + 1);
      Pares[High(Pares)] := V[i];
    end
    else
    begin
      SetLength(Impares, Length(Impares) + 1);
      Impares[High(Impares)] := V[i];
    end;
  end;
end;

function VectorPlus.Intercalar(B: TVector): TVector;
var
  i, j, k: Integer;
begin
  SetLength(Result, Length(V) + Length(B));

  i := 0;
  j := 0;
  k := 0;

  while (i < Length(V)) or (j < Length(B)) do
  begin
    if i < Length(V) then
    begin
      Result[k] := V[i];
      Inc(i);
      Inc(k);
    end;

    if j < Length(B) then
    begin
      Result[k] := B[j];
      Inc(j);
      Inc(k);
    end;
  end;
end;

procedure VectorPlus.Purgar;
var
  i, j, aux: Integer;
begin
  for i := 0 to High(V) - 1 do
    for j := i + 1 to High(V) do
      if V[i] > V[j] then
      begin
        aux := V[i];
        V[i] := V[j];
        V[j] := aux;
      end;
  if Length(V) = 0 then Exit;

  j := 0;

  for i := 1 to High(V) do
    if V[i] <> V[j] then
    begin
      Inc(j);
      V[j] := V[i];
    end;

  SetLength(V, j + 1);
end;

function VectorPlus.Mostrar: String;
var
  i: Integer;
begin
  Result := '[';

  for i := 0 to High(V) do
  begin
    Result := Result + IntToStr(V[i]);

    if i < High(V) then
      Result := Result + ', ';
  end;

  Result := Result + ']';
end;

end.

