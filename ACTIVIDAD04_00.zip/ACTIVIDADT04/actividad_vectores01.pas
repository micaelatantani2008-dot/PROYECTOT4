unit ACTIVIDAD_VECTORES01;

{$mode objfpc}{$H+}

interface

uses
 Classes, SysUtils, Forms, Controls, Graphics,
  Dialogs, StdCtrls, Grids, ACTIVIDAD_01;

type

  { TForm1 }

  TForm1 = class(TForm)
    BtnEjecutar: TButton;
    CmbOperacion: TComboBox;
    Label1: TLabel;
    Label2: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    SGA: TStringGrid;
    SGB: TStringGrid;
    SGResultado: TStringGrid;
    procedure BtnEjecutarClick(Sender: TObject);
  private
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

procedure TForm1.BtnEjecutarClick(Sender: TObject);
var
  VP: VectorPlus;
  A, B, Pares, Impares, R: TVector;
  i, valor, fila, frecuencia: Integer;
begin
  if CmbOperacion.ItemIndex = -1 then
  begin
    ShowMessage('Selecciona una operacion.');
    Exit;
  end;

  { Leer vector A }
  SetLength(A, 0);

  for i := 0 to SGA.ColCount - 1 do
    if Trim(SGA.Cells[i, 1]) <> '' then
    begin
      if not TryStrToInt(Trim(SGA.Cells[i, 1]), valor) then
      begin
        ShowMessage('Dato no valido en el vector A.');
        Exit;
      end;

      SetLength(A, Length(A) + 1);
      A[High(A)] := valor;
    end;

  if Length(A) = 0 then
  begin
    ShowMessage('Ingresa los elementos del vector A en la fila 2.');
    Exit;
  end;

  { Leer vector B }
  SetLength(B, 0);

  for i := 0 to SGB.ColCount - 1 do
    if Trim(SGB.Cells[i, 1]) <> '' then
    begin
      if not TryStrToInt(Trim(SGB.Cells[i, 1]), valor) then
      begin
        ShowMessage('Dato no valido en el vector B.');
        Exit;
      end;

      SetLength(B, Length(B) + 1);
      B[High(B)] := valor;
    end;

  VP := VectorPlus.Create;
  try
    VP.Cargar(A);

    { Preparar la tabla de resultados }
    SGResultado.FixedRows := 1;
    SGResultado.FixedCols := 0;
    SGResultado.ColCount := 2;
    SGResultado.RowCount := 2;
    SGResultado.Cells[0, 0] := 'Operacion';
    SGResultado.Cells[1, 0] := 'Resultado';
    SGResultado.Cells[0, 1] := '';
    SGResultado.Cells[1, 1] := '';

    case CmbOperacion.ItemIndex of

      0: { Cantidad de cortes de control }
      begin
        SGResultado.ColCount := 2;
        SGResultado.RowCount := 2;

        SGResultado.Cells[0, 0] := 'Operacion';
        SGResultado.Cells[1, 0] := 'Resultado';

        SGResultado.Cells[0, 1] := 'Cantidad de cortes';
        SGResultado.Cells[1, 1] :=
          IntToStr(VP.CantidadCortes);
      end;

      1: { Elementos entre cortes de control }
      begin
        SGResultado.Cells[0, 0] := 'Valor';
        SGResultado.Cells[1, 0] := 'Frecuencia';

        valor := A[0];
        frecuencia := 1;
        fila := 1;

        for i := 1 to High(A) do
        begin
          if A[i] = valor then
            Inc(frecuencia)
          else
          begin
            if fila >= SGResultado.RowCount then
              SGResultado.RowCount := fila + 1;

            SGResultado.Cells[0, fila] := IntToStr(valor);
            SGResultado.Cells[1, fila] := IntToStr(frecuencia);

            Inc(fila);
            valor := A[i];
            frecuencia := 1;
          end;
        end;

        if fila >= SGResultado.RowCount then
          SGResultado.RowCount := fila + 1;

        SGResultado.Cells[0, fila] := IntToStr(valor);
        SGResultado.Cells[1, fila] := IntToStr(frecuencia);
      end;

      2: { Dividir pares e impares }
      begin
        VP.DividirParImpar(Pares, Impares);

        SGResultado.Cells[0, 0] := 'Tipo';
        SGResultado.Cells[1, 0] := 'Valor';
        SGResultado.RowCount :=
          Length(Pares) + Length(Impares) + 1;

        fila := 1;

        for i := 0 to High(Pares) do
        begin
          SGResultado.Cells[0, fila] := 'Par';
          SGResultado.Cells[1, fila] := IntToStr(Pares[i]);
          Inc(fila);
        end;

        for i := 0 to High(Impares) do
        begin
          SGResultado.Cells[0, fila] := 'Impar';
          SGResultado.Cells[1, fila] := IntToStr(Impares[i]);
          Inc(fila);
        end;
      end;

      3: { Intercalar vectores }
      begin
        if Length(B) = 0 then
        begin
          ShowMessage('Ingresa los elementos del vector B.');
          Exit;
        end;

        R := VP.Intercalar(B);

        SGResultado.ColCount := 2;
        SGResultado.RowCount := Length(R) + 1;
        SGResultado.Cells[0, 0] := 'Posicion';
        SGResultado.Cells[1, 0] := 'Valor';

        for i := 0 to High(R) do
        begin
          SGResultado.Cells[0, i + 1] := IntToStr(i + 1);
          SGResultado.Cells[1, i + 1] := IntToStr(R[i]);
        end;
      end;

      4: { Purgar elementos }
      begin
        VP.Purgar;

        SGResultado.Cells[0, 0] := 'Operacion';
        SGResultado.Cells[1, 0] := 'Resultado';
        SGResultado.Cells[0, 1] := 'Vector purgado';
        SGResultado.Cells[1, 1] := VP.Mostrar;
      end;

    end;

  finally
    VP.Free;
  end;
end;



end.
